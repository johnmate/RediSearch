# Library cluster of common Redis Modules automation code

Cetara: C/C++

Paella: Python

Shibumi: Bash

mk: GNU Make
