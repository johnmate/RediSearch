# Libnu

The files in this folder are taken from the (excellent) **nunicode** library by Aleksey Tulinov.

See [https://bitbucket.org/alekseyt/nunicode](https://bitbucket.org/alekseyt/nunicode)
